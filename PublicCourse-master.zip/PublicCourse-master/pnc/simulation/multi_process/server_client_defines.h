// Copyright @2018 Pony AI Inc. All rights reserved.

#pragma once

namespace simulation {

constexpr char kLocalHost[] = "127.0.0.1";
constexpr int kPort = 12312;
}
