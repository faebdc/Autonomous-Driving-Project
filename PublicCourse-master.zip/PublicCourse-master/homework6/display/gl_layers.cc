// Copyright @2018 Pony AI Inc. All rights reserved.

#include "homework6/display/gl_layers.h"

namespace utils {
namespace display {

float GetGlLayer(GlLayers l) { return l * 0.02f; }

}  // namespace display
}  // namespace utils
