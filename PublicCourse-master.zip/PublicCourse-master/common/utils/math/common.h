#pragma once

namespace math {

constexpr double kEpsilon = 1e-9;

}  // namespace math
