// Copyright @2018 Pony AI Inc. All rights reserved.

#include "common/utils/strings/string_view.h"

namespace strings {

constexpr int StringView::kEnd;

}  // namespace strings
