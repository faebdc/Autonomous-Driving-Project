Please run following command to install required dependencies before using the source code in this directory. 
```
sudo apt install qtdeclarative5-dev clang-3.8 nasm
```
